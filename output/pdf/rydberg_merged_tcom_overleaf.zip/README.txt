MERGED TCOM MANUSCRIPT

Main document: merged_tcom.tex
Compiler: pdfLaTeX; bibliography: BibTeX / IEEEtran.
Upload the complete Overleaf ZIP, then select merged_tcom.tex as the main file.
Compile with pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX.
The included BBL is a convenience; references.bib is the editable bibliography.

This merges the latest full P1 revision with the P2 round-two revision chosen
by the author. It is a new, independent source; the separate papers are intact.
No new channel simulations, training or comparative test runs were performed
for this merge. Existing results are reorganized; one plot is redrawn from its
saved summaries for legibility. The figure script and exact input summaries
are included. They are not the complete experimental reproduction archive.

Format checked against the TCOM author guidelines on 8 October 2026:
https://www.comsoc.org/publications/journals/ieee-tcom/policies-and-guidelines
10-point IEEEtran journal text, double column, single spaced, one-inch margins,
letter paper, 171-word abstract and five index terms. The compiled PDF has ten
pages including references. Initial TCOM submissions permit at most 13 pages;
revised submissions permit 16. Traditional publication does not require paying
the voluntary first-ten-page charges. Mandatory charges apply above ten printed
pages. Final publisher pagination, additional authors and later revisions may
change the page count: this manuscript is not a guarantee of zero final charges.
Do not select paid open access if traditional publication is intended.

The built-in single-file Codex compiler cannot resolve this project's external
figures/bibliography. The complete project was compiled with local TeX Live
2026 and separately recompiled from the ZIP. Use the delivered PDF or Overleaf
for the correct output. No font, margin or spacing tricks are used to fit it.

See MERGE_NOTES.txt for the scientific scope, source mapping and remaining
submission decisions. This is a combined manuscript for author review, not a
claim of editorial acceptance or confirmation of every submission prerequisite.
